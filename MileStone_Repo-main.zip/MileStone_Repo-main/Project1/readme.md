PROJECT-1

![Screenshot 2023-07-20 183218](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/8201f39b-c54b-44b8-90a3-e482aaabeb24)
![Screenshot 2023-07-20 183235](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/e563efbc-9f19-4934-acb2-abedb2625051)
