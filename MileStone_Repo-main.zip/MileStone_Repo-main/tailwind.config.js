/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./project3/dist/*.html","./project4/dist/*.html","./project5/dist/*.html"],
  theme: {
    extend: {},
  },
  plugins: [],
}

