PROJECT-1

![Screenshot 2023-07-20 183218](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/aee6b78c-170c-4ec6-a604-510bdff6f031)
![Screenshot 2023-07-20 183235](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/ca643ae0-19e6-428d-b5e1-8408b0a9f83c)


PROJECT-2

![Screenshot 2023-07-20 182516](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/8ef0a700-d426-4dd4-9756-d2847a5b8681)
![Screenshot 2023-07-20 182534](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/9410b7f4-4583-43fd-a32b-a515dcf18918)
![Screenshot 2023-07-20 182553](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/43347a2b-8ff5-4285-a13e-25cd88b7e358)
![Screenshot 2023-07-20 182611](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/e6040151-ba26-4653-bb5b-c24db753d8af)
![Screenshot 2023-07-20 182647](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/bc22339d-0b25-4764-9052-e2242fb3d0a6)
![Screenshot 2023-07-20 182703](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/70e2f9ad-5d9a-4eb9-b14f-fd4e8b7f39e1)
![Screenshot 2023-07-20 182716](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/29523e26-4e12-427f-8022-2d49f86e05d0)


PROJECT-3

![Screenshot 2023-07-22 105331](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/0f6f4762-66df-45d7-9518-71d011434716)
![Screenshot 2023-07-22 105354](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/474ba6cd-1115-435c-ba2b-daed93a2444d)
![Screenshot 2023-07-22 105433](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/a541965f-dab8-47b0-b06e-3f0908fe12a4)
![Screenshot 2023-07-22 105459](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/2aaaac8b-4e11-4856-af21-247e3ee8ec45)
![Screenshot 2023-07-22 105519](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/e1993160-5ff8-49c3-b94a-65f914966950)
![Screenshot 2023-07-22 105537](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/dc4edd81-3e90-489c-a68f-9997c9f63ed2)
![Screenshot 2023-07-22 105557](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/d178dce8-6982-4a6e-ab1a-632b5e89631f)
![Screenshot 2023-07-22 105616](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/9f727e99-77f6-4b3b-b298-635e2ff7bea1)
![Screenshot 2023-07-22 105633](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/830a0bba-25a6-4cb4-97f9-2b360d6a81c6)
![Screenshot 2023-07![Screenshot 2023-07-22 105739](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/76313774-e94b-4570-a79d-8f7caa8162e5)
-22 105723](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/7077b78b-8d97-4688-ad73-149e3d2da074)
![Screenshot 2023-07-22 105739](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/7412c3e8-9e23-4d5f-bf3c-cf8b20ee3ea8)
![Screenshot 2023-07-22 105755](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/4fe2e1dc-abb5-4e63-b035-ed81b47f478b)
![Screenshot 2023-07-22 105814](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/0dcdcf9c-fd4f-4e08-b01f-6e98ab818ae4)
![Screenshot 2023-07-22 105830](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/483bf028-2bd4-4abe-977b-b9b3ae969803)

PROJECT-4

![Screenshot 2023-07-25 195533](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/7c84336e-3fb4-4992-b4fe-70dac726cd87)
![Screenshot 2023-07-25 113432](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/a1f00513-5991-44b4-a031-1e17ed57fbdd)
![Screenshot 2023-07-25 113458](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/09b33e98-776e-4142-b8e6-1a88153be92c)
![Screenshot 2023-07-25 113511](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/6caf76bb-6d03-4063-803c-fed3d34b5edf)
![Screenshot 2023-07-25 113556](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/a3a88e82-ca25-43d9-8b6e-cbf0724d550e)
![Screenshot 2023-07-25 113626](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/6f2dab2c-ff1a-4647-adc6-59519a7a5ba4)
![Screenshot 2023-07-25 113653](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/a1e5e66a-72a0-44de-bbc7-e19973174d19)
![Screenshot 2023-07-25 113711](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/f432e959-c74e-4fc4-b87a-e682c0324a0a)
![Screenshot 2023-07-25 113728](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/883200bb-0f35-46a0-b848-d012cd7efd79)
![Screenshot 2023-07-25 113743](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/7878e0ef-aadd-4c25-9830-753edd63f715)


PROJECT-5

![Screenshot 2023-07-25 114001](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/07daf113-579f-4f4d-9942-948b10296a1e)
![Screenshot 2023-07-25 114026](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/7b7bea79-b219-471b-bfa2-230116a2c5bd)
![Screenshot 2023-07-25 114047](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/c6c2ebfc-1206-4626-806a-021458ca53b9)
![Screenshot 2023-07-25 114105](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/d6721a42-0baf-41c1-9858-c9e594b3bad4)
![Screenshot 2023-07-25 114119](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/c2de25e0-6e2a-4afd-9e99-1102dc71c4df)
![Screenshot 2023-07-25 114151](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/92d3c6b1-f5f6-483b-a637-1bd451576cc5)
![Screenshot 2023-07-25 114212](https://github.com/Sujit-Panigrahi5/MileStone_Repo/assets/128701820/1fb45972-df0c-40f7-bf85-b9e307cec676)
